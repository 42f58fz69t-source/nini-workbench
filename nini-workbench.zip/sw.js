const CACHE = 'nini-v5';
const FILES = [
  './', './index.html', './app.js', './builtin-data.js',
  './manifest.json', './icon-192.png', './icon-512.png'
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(FILES).catch(() => {}))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// 网络优先：联网时拿最新数据并更新缓存，离线时用缓存
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  // 对 builtin-data.js 特殊处理：始终尝试网络，失败则用缓存
  e.respondWith(
    fetch(e.request).then(networkResp => {
      if (networkResp && networkResp.status === 200) {
        const copy = networkResp.clone();
        caches.open(CACHE).then(c => c.put(e.request, copy)).catch(() => {});
      }
      return networkResp;
    }).catch(() =>
      caches.match(e.request).then(cached =>
        cached || caches.match('./index.html')
      )
    )
  );
});
